# Homework 8

## Artiukhov Dmitrii

All solutions for the text tasks are inside of the `solution.pdf` file.

The C programm source code is in `3.c` file. To build run `make`.