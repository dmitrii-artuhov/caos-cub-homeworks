# Homework 6

## Artiukhov Dmitrii

All solutions are inside of the `solution.pdf` file.