# Homework 5

## Artiukhov Dmitrii

### Task 1:
- **(a)**: hmmmm, not sure
- **(b)**: completed in `1.c` file.